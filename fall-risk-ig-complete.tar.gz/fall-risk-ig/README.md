# Fall Risk Assessment — FHIR Implementation Guide

A standardized, interoperable FHIR R4 approach for fall risk assessment in older adults.

🌐 **Live IG:** https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/

---

## What this is

This is a FHIR Implementation Guide (IG) that defines:
- 4 FHIR profiles (Observation variants + Patient)
- 3 ValueSets (risk factors, performance tests, categories)
- Real FHIR JSON examples (Patient, Observations, Condition)
- Human-readable pages explaining the architecture and data flow

---

## Prerequisites (install once)

| Tool | Purpose | Install |
|---|---|---|
| Java 17+ | Runs IG Publisher | https://adoptium.net |
| Node.js 18+ | Runs SUSHI | https://nodejs.org |
| SUSHI | Compiles FSH → FHIR | `npm install -g fsh-sushi` |
| Jekyll | Generates HTML pages | `gem install jekyll bundler` |

Download IG Publisher (run once in project folder):
```bash
mkdir -p input-cache
curl -L https://github.com/HL7/fhir-ig-publisher/releases/latest/download/publisher.jar \
  -o input-cache/publisher.jar
```

---

## How to build locally

```bash
# 1. Clone the repo
git clone https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git
cd YOUR-REPO-NAME

# 2. Compile FSH files into FHIR resources
sushi .

# 3. Run IG Publisher (this also runs Jekyll internally)
java -jar input-cache/publisher.jar -ig ig.ini

# 4. View the result
open output/index.html
```

That's it! The full website is in the `output/` folder.

---

## How to publish to GitHub Pages

### One-time setup:
1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set Source to: **Branch: main, Folder: /docs**
4. Click Save

### Every time you update:
```bash
# Make your changes to FSH or markdown files, then:
sushi .
java -jar input-cache/publisher.jar -ig ig.ini
cp -r output/* docs/
git add docs/
git commit -m "Publish updated IG"
git push
```

GitHub Pages will update within ~1 minute.

### Automatic publishing (optional):
The `.github/workflows/publish.yml` file will do steps above automatically on every push to `main`. Just enable GitHub Actions in your repo settings.

---

## Project structure

```
fall-risk-ig/
├── input/
│   ├── fsh/
│   │   └── fall-risk.fsh          ← All profiles, valuesets, instances
│   ├── pagecontent/
│   │   ├── index.md               ← Home page
│   │   ├── usecase.md             ← Clinical background
│   │   ├── architecture.md        ← Diagram + technical architecture
│   │   ├── dataflow.md            ← Score calculation rules
│   │   └── examples.md            ← Annotated FHIR JSON
│   └── examples/
│       ├── patient-example.json
│       ├── observation-fear-of-falling.json
│       ├── observation-tug-test.json
│       ├── observation-fall-risk-score.json
│       ├── observation-fall-risk-result.json
│       ├── condition-fall-risk.json
│       └── questionnaire-response-falls.json
├── docs/                          ← Published website (GitHub Pages)
├── sushi-config.yaml              ← IG metadata and page list
├── ig.ini                         ← IG Publisher config
└── .gitignore
```

---

## Making changes

### To edit profiles:
Edit `input/fsh/fall-risk.fsh` → run `sushi .` → run IG Publisher

### To edit pages:
Edit markdown files in `input/pagecontent/` → run IG Publisher (no SUSHI needed)

### To add a new example:
1. Add a JSON file to `input/examples/`
2. Reference it in `input/fsh/fall-risk.fsh` as an `Instance`
3. Run `sushi .` → run IG Publisher

### To check for errors:
Open `output/qa.html` in your browser after every build.

---

## Checking the build

After running IG Publisher, always check:
- `output/qa.html` — lists all errors and warnings
- `output/index.html` — the actual website
- Look for broken links (IG Publisher reports these)

---

## License

CC0 1.0 Universal — free to use without restrictions.
