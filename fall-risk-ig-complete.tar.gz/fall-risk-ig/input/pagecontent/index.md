# Fall Risk Assessment Implementation Guide

**Version:** 0.1.0 (CI Build) &nbsp;|&nbsp; **Status:** Draft &nbsp;|&nbsp; **FHIR Version:** R4 (4.0.1)

---

## What is this guide?

This Implementation Guide (IG) defines a **standardized, interoperable FHIR R4 approach** for assessing fall risk in older adults. Falls are the leading cause of injury-related death and hospitalization in people aged 65 and over. Early, structured identification of at-risk individuals enables timely preventive action.

This guide shows clinicians, developers, and system integrators exactly how to:

- Capture **10 clinical risk factors** in standardized FHIR resources  
- Record **3 objective physical performance tests** with coded results  
- Automatically pull relevant data **from existing EHR records**  
- Calculate a **composite fall risk score (0–30)** in a traceable, auditable way  
- Classify patients as **Low / Moderate / High** risk  
- Add a **problem list entry** that travels with the patient across systems  

---

## Scope

| In Scope | Out of Scope |
|---|---|
| Standardized FHIR representation of 13 fall risk factors | Specific intervention protocols |
| Score calculation methodology | Medication dose adjustment logic |
| EHR data extraction approach | Wearable / continuous monitoring integration |
| FHIR RiskAssessment + Condition creation | Billing / reimbursement workflows |
| Example instances (Patient, Observations, Condition) | Regional legal / consent requirements |

---

## Target Audience

- **Healthcare informaticians** designing FHIR interfaces  
- **EHR vendors** implementing fall risk modules  
- **Clinical developers** building fall risk apps or CDS Hooks  
- **Researchers** who need a standardized fall risk dataset  

---

## How to navigate this guide

| Page | Contents |
|---|---|
| **[Use Case](usecase.html)** | Clinical background, patient journey, why FHIR matters |
| **[Architecture](architecture.html)** | Visual system diagram, FHIR resource layers |
| **[Data Flow & Scoring](dataflow.html)** | How factors become a score, calculation rules |
| **[Examples](examples.html)** | Real FHIR JSON instances with annotations |
| **[Artifacts](artifacts.html)** | All profiles, value sets, and instances |

---

## Quick Start

If you want to implement this IG immediately, here is the minimal set of resources you need:

```
Patient                      → who is being assessed
FallRiskFactorObservation    → one per risk factor (up to 13)
FallRiskPerformanceObservation → one per physical test (up to 3)
FallRiskScoreObservation     → the aggregate score (0–30)
FallRiskObservation          → the final classification (Low/Moderate/High)
Condition                    → problem list entry "At risk of fall"
```

See the [Examples page](examples.html) for ready-to-use JSON you can paste into your system.

---

## Authors & Acknowledgements

This IG was developed as part of an academic project on interoperable geriatric assessment frameworks. It follows HL7 FHIR R4 standards and references LOINC, SNOMED CT, ICD-10, and UCUM terminologies.
