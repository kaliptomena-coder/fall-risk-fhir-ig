# Use Case: Fall Risk Assessment in Older Adults

## Clinical Background

Falls are one of the most serious and costly problems in geriatric medicine:

- **1 in 3** adults over 65 falls at least once per year
- Falls are the **leading cause** of injury-related death in this age group
- A single hip fracture costs an average of **€25,000–40,000** in acute care alone
- Most falls are **preventable** with early identification and targeted intervention

Current practice in many hospitals and community settings is fragmented: risk factors are assessed in different systems, with different tools, by different clinicians — and the results rarely travel with the patient.

This IG solves that by encoding the entire assessment in **interoperable FHIR resources** that can be created in one system and consumed in any other.

---

## Patient Journey

### Meet Maria Müller (78 years old)

Maria lives alone in Vienna. Her GP has noticed she walks more slowly than last year. A neighbour mentioned Maria stumbled on the stairs last month. Maria herself is nervous about falling — she's started avoiding her weekly walk to the market.

```
GP Visit → Fall Risk Screening Initiated
     │
     ├─ Nurse reviews EHR:
     │    • 7 medications (2 high-risk)
     │    • Diagnosis: Type 2 Diabetes, mild hypertension
     │    • MMSE score from last year: 24/30
     │
     ├─ Nurse asks Maria directly:
     │    • 2 falls in past 12 months ✓
     │    • Fear of falling: 55% confidence (ABC Scale) ✓  
     │    • Alcohol: 3 units/week
     │    • Physical activity: light activity only
     │    • ADL: mostly independent, needs help bathing
     │
     ├─ Physiotherapist runs objective tests:
     │    • TUG: 14.2 seconds  (risk threshold: >12s) ✗
     │    • Chair Stand: 8 reps in 30s  (low for age) ✗
     │    • Balance Test: stage 2 only  (cannot tandem stand) ✗
     │
     └─ System calculates score: 18/30 → MODERATE RISK
          │
          └─ Condition "At risk of fall" added to problem list
               Referral to falls prevention program sent
```

### What happens in FHIR

Each step above produces one or more FHIR resources:

| Clinical Step | FHIR Resource | Profile Used |
|---|---|---|
| EHR medication review | MedicationStatement → Observation | FallRiskFactorObservation |
| Nurse questionnaire (falls, fear) | QuestionnaireResponse → Observation | FallRiskFactorObservation |
| TUG test result | Observation | FallRiskPerformanceObservation |
| Chair Stand result | Observation | FallRiskPerformanceObservation |
| Score calculation | Observation (18/30) | FallRiskScoreObservation |
| Risk classification | Observation (Moderate) | FallRiskObservation |
| Problem list entry | Condition | Core FHIR Condition |

---

## Why Not Just Use a Paper Form?

| Problem | FHIR Solution |
|---|---|
| Results stay in one system | Any FHIR-capable system can read the data |
| Different hospitals use different tools | Standardized codes (LOINC, SNOMED) |
| No audit trail for scores | `derivedFrom` links every score to its inputs |
| Impossible to aggregate research data | Common data model across institutions |
| Manual re-entry causes errors | EHR data auto-populated via `MedicationStatement`, `Condition` |

---

## Supported Risk Factors

This guide supports all 13 factors in the evidence-based fall risk model:

### Group A — From EHR (automated)
| # | Factor | FHIR Source |
|---|---|---|
| 3 | Medications count + high-risk meds | `MedicationStatement` |
| 4 | Number of comorbidities | `Condition` resources |
| 5 | Cognitive function (MMSE) | existing `Observation` |
| 6 | Vision & hearing impairment | existing `Observation` |

### Group B — Questionnaire (manual entry)
| # | Factor | Standard |
|---|---|---|
| 1 | Falls in past 12 months | SNOMED 428807008 |
| 2 | Fear of falling (ABC Scale) | LOINC 95418-0 |
| 7 | Alcohol use (units/week) | LOINC 74013-4 |
| 8 | Physical activity level | LOINC 80582-0 |
| 9 | ADL independence | SNOMED 284545001 |
| 10 | Walking ability | SNOMED ValueSet |

### Group C — Physical performance tests
| Code | Test | LOINC | Unit |
|---|---|---|---|
| a | 30-Second Chair Stand | 82755-5 | {repetitions} |
| b | 4-Stage Balance Test | 92631-9 | CodeableConcept |
| c | Timed Up and Go (TUG) | 80456-7 | seconds |

---

## Benefits for Different Stakeholders

**For clinicians:** The score is transparent — every point can be traced back to a specific observation with a timestamp and a source.

**For patients:** Their risk profile travels with them between GP, hospital, and rehabilitation — no need to repeat the assessment from scratch.

**For researchers:** A standardized dataset means multi-site studies and quality improvement programs can aggregate data meaningfully.

**For IT teams:** A well-defined FHIR profile means integration projects have a clear target — no guesswork about field names or code systems.
