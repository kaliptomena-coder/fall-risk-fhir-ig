// ╔══════════════════════════════════════════════════════════════╗
// ║        FALL RISK ASSESSMENT - FHIR SHORTHAND (FSH)          ║
// ║   Profiles, ValueSet, and FHIR instances for fall risk IG   ║
// ╚══════════════════════════════════════════════════════════════╝

// ─── ALIASES ────────────────────────────────────────────────────
Alias: $LOINC   = http://loinc.org
Alias: $SNOMED  = http://snomed.info/sct
Alias: $UCUM    = http://unitsofmeasure.org
Alias: $OBS_CAT = http://terminology.hl7.org/CodeSystem/observation-category

// ════════════════════════════════════════════════════════════════
// 1.  PROFILES
// ════════════════════════════════════════════════════════════════

// ── 1a. Generic Fall Risk Factor Observation ────────────────────
Profile: FallRiskFactorObservation
Parent: Observation
Id: fall-risk-factor-observation
Title: "Fall Risk Factor Observation"
Description: """
A standardized FHIR Observation representing a single contributing factor
to fall risk (e.g., fear of falling, walking ability, alcohol use).

Both auto-populated EHR data and manually entered questionnaire answers
are ultimately stored in this format, ensuring a uniform interface for
the scoring algorithm.
"""
* status 1..1 MS
* status = #final
* category 1..* MS
* category = $OBS_CAT#survey "Survey"
* code 1..1 MS
* subject 1..1 MS
* subject only Reference(Patient)
* effective[x] 1..1 MS
* effective[x] only dateTime
* value[x] 1..1 MS
* method MS
* derivedFrom MS
* derivedFrom only Reference(QuestionnaireResponse or Observation)

// ── 1b. Fall Risk Score (aggregate) ─────────────────────────────
Profile: FallRiskScoreObservation
Parent: Observation
Id: fall-risk-score-observation
Title: "Fall Risk Score Observation"
Description: """
The aggregated fall risk score (0–30) computed from all individual
Fall Risk Factor Observations.  hasMember links back to every
contributing factor so the chain of evidence is traceable.
"""
* status 1..1 MS
* status = #final
* category 1..* MS
* category = $OBS_CAT#survey "Survey"
* code 1..1 MS
* code = $LOINC#75218-8 "Fall risk total score"
* subject 1..1 MS
* subject only Reference(Patient)
* effective[x] 1..1 MS
* effective[x] only dateTime
* value[x] 1..1 MS
* value[x] only Quantity
* valueQuantity.system = $UCUM
* valueQuantity.unit = "score"
* valueQuantity.code = #{score}
* hasMember MS
* hasMember only Reference(FallRiskFactorObservation)

// ── 1c. Objective Performance Test Observation ──────────────────
Profile: FallRiskPerformanceObservation
Parent: Observation
Id: fall-risk-performance-observation
Title: "Fall Risk Performance Test Observation"
Description: """
Objective physical performance measurements used in fall risk assessment:
30-Second Chair Stand Test, 4-Stage Balance Test, and Timed Up & Go (TUG).

These are stored with standardized LOINC codes and UCUM units so results
are directly comparable across institutions.
"""
* status 1..1 MS
* status = #final
* category 1..* MS
* category = $OBS_CAT#exam "Exam"
* code 1..1 MS
* code from FallRiskPerformanceTestsVS (required)
* subject 1..1 MS
* subject only Reference(Patient)
* effective[x] 1..1 MS
* effective[x] only dateTime
* value[x] 1..1 MS
* derivedFrom MS

// ── 1d. Fall Risk Assessment Observation (screening result) ─────
Profile: FallRiskObservation
Parent: Observation
Id: fall-risk-observation
Title: "Fall Risk Observation"
Description: """
The outcome of a fall risk screening episode, capturing the overall
risk classification (Low / Moderate / High) and referencing the
aggregated score Observation.
"""
* status 1..1 MS
* status = #final
* code 1..1 MS
* code = $LOINC#71802-3 "Fall risk screening"
* subject 1..1 MS
* subject only Reference(Patient)
* effective[x] 1..1 MS
* value[x] 1..1 MS
* value[x] only CodeableConcept
* valueCodeableConcept from FallRiskCategoryVS (required)
* derivedFrom 1..* MS
* derivedFrom only Reference(FallRiskScoreObservation)

// ════════════════════════════════════════════════════════════════
// 2.  VALUE SETS
// ════════════════════════════════════════════════════════════════

ValueSet: FallRiskFactorsVS
Id: fall-risk-factors-vs
Title: "Fall Risk Factors ValueSet"
Description: "Standardized LOINC / SNOMED codes for all fall risk assessment inputs."
* $LOINC#71802-3  "Fall risk screening"
* $LOINC#80456-7  "Timed Up and Go Test"
* $LOINC#82755-5  "30-Second Chair Stand Test"
* $LOINC#92631-9  "4-Stage Balance Test"
* $LOINC#95418-0  "ABC Scale – fear of falling"
* $LOINC#72107-6  "Mini-Mental State Exam score"
* $LOINC#74013-4  "Alcohol use"
* $LOINC#80582-0  "Physical activity"
* $SNOMED#428807008 "History of fall"
* $SNOMED#397540003 "Visual impairment"
* $SNOMED#284545001 "Activity of Daily Living"

ValueSet: FallRiskPerformanceTestsVS
Id: fall-risk-performance-tests-vs
Title: "Fall Risk Performance Tests ValueSet"
Description: "LOINC codes for objective physical performance tests used in fall risk assessment."
* $LOINC#80456-7 "Timed Up and Go Test"
* $LOINC#82755-5 "30-Second Chair Stand Test"
* $LOINC#92631-9 "4-Stage Balance Test"

ValueSet: FallRiskCategoryVS
Id: fall-risk-category-vs
Title: "Fall Risk Category ValueSet"
Description: "Coded risk classification outcomes: Low, Moderate, High."
* $SNOMED#723510000 "Low risk"
* $SNOMED#723511001 "Moderate risk"
* $SNOMED#723505004 "High risk"

// ════════════════════════════════════════════════════════════════
// 3.  INSTANCES  (examples registered in IG)
// ════════════════════════════════════════════════════════════════

Instance: ExamplePatient
InstanceOf: Patient
Title: "Example Patient – Maria Müller"
Description: "A 78-year-old female patient undergoing fall risk assessment."
Usage: #example
* id = "example-patient"
* name
  * family = "Müller"
  * given[0] = "Maria"
* gender = #female
* birthDate = "1946-03-12"
* address
  * line[0] = "Hauptstraße 15"
  * city = "Vienna"
  * country = "AT"

Instance: ExampleFearOfFallingObservation
InstanceOf: FallRiskFactorObservation
Title: "Example – Fear of Falling (Factor 2)"
Description: "Patient reports 55% confidence on the ABC Scale."
Usage: #example
* id = "obs-fear-of-falling"
* status = #final
* category = $OBS_CAT#survey "Survey"
* code = $LOINC#95418-0 "ABC Scale – fear of falling"
* subject = Reference(ExamplePatient)
* effectiveDateTime = "2024-11-15T10:30:00+01:00"
* valueQuantity
  * value = 55
  * unit = "%"
  * system = $UCUM
  * code = #%

Instance: ExampleTUGObservation
InstanceOf: FallRiskPerformanceObservation
Title: "Example – Timed Up and Go Test"
Description: "Patient completed TUG in 14.2 seconds (elevated risk threshold >12 s)."
Usage: #example
* id = "obs-tug-test"
* status = #final
* category = $OBS_CAT#exam "Exam"
* code = $LOINC#80456-7 "Timed Up and Go Test"
* subject = Reference(ExamplePatient)
* effectiveDateTime = "2024-11-15T10:45:00+01:00"
* valueQuantity
  * value = 14.2
  * unit = "s"
  * system = $UCUM
  * code = #s

Instance: ExampleChairStandObservation
InstanceOf: FallRiskPerformanceObservation
Title: "Example – 30-Second Chair Stand Test"
Description: "Patient completed 8 repetitions in 30 seconds."
Usage: #example
* id = "obs-chair-stand"
* status = #final
* category = $OBS_CAT#exam "Exam"
* code = $LOINC#82755-5 "30-Second Chair Stand Test"
* subject = Reference(ExamplePatient)
* effectiveDateTime = "2024-11-15T10:50:00+01:00"
* valueQuantity
  * value = 8
  * unit = "repetitions"
  * system = $UCUM
  * code = #{repetition}

Instance: ExampleFallRiskScore
InstanceOf: FallRiskScoreObservation
Title: "Example – Fall Risk Score (18/30)"
Description: "Aggregated fall risk score of 18 out of 30 — Moderate risk."
Usage: #example
* id = "obs-fall-risk-score"
* status = #final
* category = $OBS_CAT#survey "Survey"
* code = $LOINC#75218-8 "Fall risk total score"
* subject = Reference(ExamplePatient)
* effectiveDateTime = "2024-11-15T11:00:00+01:00"
* valueQuantity
  * value = 18
  * unit = "score"
  * system = $UCUM
  * code = #{score}
* hasMember[0] = Reference(ExampleFearOfFallingObservation)
* hasMember[1] = Reference(ExampleTUGObservation)
* hasMember[2] = Reference(ExampleChairStandObservation)

Instance: ExampleFallRiskAssessment
InstanceOf: FallRiskObservation
Title: "Example – Fall Risk Screening Result"
Description: "Overall fall risk classification: Moderate."
Usage: #example
* id = "obs-fall-risk-result"
* status = #final
* code = $LOINC#71802-3 "Fall risk screening"
* subject = Reference(ExamplePatient)
* effectiveDateTime = "2024-11-15T11:00:00+01:00"
* valueCodeableConcept = $SNOMED#723511001 "Moderate risk"
* derivedFrom = Reference(ExampleFallRiskScore)

Instance: ExampleFallRiskCondition
InstanceOf: Condition
Title: "Example – Condition: At Risk of Falls"
Description: "Problem list entry created after moderate fall risk assessment."
Usage: #example
* id = "condition-fall-risk"
* clinicalStatus = http://terminology.hl7.org/CodeSystem/condition-clinical#active
* verificationStatus = http://terminology.hl7.org/CodeSystem/condition-ver-status#confirmed
* code = $SNOMED#225444004 "At risk of fall"
* subject = Reference(ExamplePatient)
* onsetDateTime = "2024-11-15"
* evidence[0].detail = Reference(ExampleFallRiskAssessment)

Instance: ExampleFallsHistoryQR
InstanceOf: QuestionnaireResponse
Title: "Example – Falls History QuestionnaireResponse"
Description: "Patient reports 2 falls in the past 12 months."
Usage: #example
* id = "qr-falls-history"
* status = #completed
* subject = Reference(ExamplePatient)
* authored = "2024-11-15T10:00:00+01:00"
* item[0]
  * linkId = "falls-count"
  * text = "How many times have you fallen in the last 12 months?"
  * answer[0].valueInteger = 2
